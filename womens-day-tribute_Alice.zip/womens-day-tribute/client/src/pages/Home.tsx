import { Heart } from "lucide-react";

export default function Home() {
  const photos = [
    {
      id: 1,
      src: "/oteuolhar.jpeg",
      title: "O teu olhar",
      description: "O Teu Olhar"
    },
    {
      id: 2,
      src: "/aventuraadois.jpeg",
      title: "Aventura a dois",
      description: "Mini aventura"
    },
    {
      id: 3,
      src: "/quetunemsabesdaexistência.jpeg",
      title: "Que tu nem sabes da existência",
      description: "Rara Esta"
    },
    {
      id: 4,
      src: "/oteusorriso.jpeg",
      title: "O teu sorriso",
      description: "O Teu Sorriso"
    }
    {
      id: 5,
      src: "/momentoengraçado.jpeg",
      title:"Momento engraçado",
      description: "Engraçada"
    }
    {
      id: 6,
      src: "/Inesquecível",
      title:"Inesquecível",
      description: "Inesquecível"
    }
  ];

  const reasons = [
    "Pelo teu sorriso que ilumina os meus dias",
    "Pela tua força que me inspira todos os dias",
    "Pelo teu abraço que é o meu lugar favorito",
    "Pela tua paciência infinita comigo",
    "Por seres a pessoa mais incrível que conheço",
    "Por fazeres de cada momento algo especial",
    "Por me fazeres querer ser melhor",
    "Por seres tu, simplesmente tu"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-white to-pink-50">
      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20 overflow-hidden">
        {/* Decorative floral elements */}
        <div className="absolute top-10 left-10 opacity-20 text-pink-300 text-6xl">🌸</div>
        <div className="absolute bottom-20 right-10 opacity-20 text-pink-300 text-6xl">🌹</div>
        <div className="absolute top-1/3 right-20 opacity-10 text-pink-400 text-8xl">✿</div>

        <div className="text-center space-y-6 max-w-2xl">
          <p className="text-sm tracking-widest text-pink-600 font-light">8 de Março</p>
          <h1 className="text-6xl md:text-7xl font-serif text-gray-800">Para Ti</h1>
          <p className="text-xl md:text-2xl text-pink-600 font-light italic">Feliz Dia da Mulher</p>
          <div className="flex justify-center pt-4">
            <Heart className="w-8 h-8 text-pink-500 fill-pink-500" />
          </div>
        </div>

        <div className="mt-20 max-w-3xl text-center space-y-6 text-gray-700 leading-relaxed">
          <p className="text-lg">
            Meu amor,
          </p>
          <p>
            Hoje é um dia especial, mas para mim todos os dias ao teu lado são especiais. Quero que saibas o quanto sou grato por te ter na minha vida.
          </p>
          <p>
            Tu és a mulher mais incrível que conheço. A tua força, a tua ternura, o teu sorriso, a tua paciência — tudo em ti me faz querer ser melhor a cada dia.
          </p>
          <p>
            Esta página é a minha forma de te dizer: obrigado por existires, obrigado por seres quem és, obrigado por me deixares fazer parte da tua história.
          </p>
        </div>
      </section>

      {/* Photos Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif text-gray-800 mb-4">Os Nossos Momentos</h2>
            <p className="text-gray-600 text-lg">Cada foto conta a nossa história</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {photos.map((photo) => (
              <div key={photo.id} className="group">
                <div className="relative overflow-hidden rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300 h-96">
                  <img
                    src={photo.src}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                </div>
                <div className="mt-6 text-center">
                  <h3 className="text-xl font-serif text-gray-800 mb-2">{photo.title}</h3>
                  <p className="text-gray-600 italic">{photo.description}</p>
                </div>
              </div>
            ))}
          </div>

          <p className="text-center text-gray-500 mt-16 italic">
            Os espaços estão reservados para as nossas fotos favoritas
          </p>
        </div>
      </section>

      {/* Reasons Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-pink-50 to-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif text-gray-800 mb-4">Razões Para Te Agradecer</h2>
            <p className="text-gray-600 text-lg">Podiam ser mil, mas aqui ficam algumas</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {reasons.map((reason, index) => (
              <div key={index} className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <Heart className="w-5 h-5 text-pink-500 fill-pink-500 flex-shrink-0 mt-1" />
                <p className="text-gray-700 leading-relaxed">{reason}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Closing Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-serif text-gray-800">
            Obrigado por Seres<br />
            <span className="text-pink-600">Quem És</span>
          </h2>

          <p className="text-lg text-gray-700 leading-relaxed">
            Que este dia te lembre o quanto és amada, admirada e especial. Não só hoje, mas todos os dias da nossa vida juntos.
          </p>

          <div className="space-y-4 pt-8">
            <p className="text-gray-700">Com todo o meu amor,</p>
            <p className="text-gray-600 italic">Kevin Alexandre</p>
          </div>

          <div className="flex justify-center items-center space-x-2 pt-12 text-pink-600">
            <span>Feito com</span>
            <Heart className="w-5 h-5 fill-pink-600" />
            <span>para ti</span>
          </div>

          <p className="text-sm text-gray-500 pt-8">Feliz Dia da Mulher 2026</p>
        </div>
      </section>
    </div>
  );
}
